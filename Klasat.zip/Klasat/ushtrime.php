<?php

include "Telefoni.php";


$samsung = new Telefoni;
$iphone = new Telefoni();


$samsung->marka = 'Samsung';
$samsung->viti = '2016';
$samsung->vendos_ramin(16);
$samsung->vendos_versionin('A5');
$samsung->vendos_kameren('13px');



$iphone->marka = 'Iphone';
$iphone->viti = '2016';
$iphone->vendos_ramin(32);
$iphone->vendos_versionin('6');
$iphone->vendos_kameren('12px');

echo "<h2>Te dhenat e Telefonit: </h2> <br>";

echo "Marka: $samsung->marka <br>";
echo "Viti i prodhimit: $samsung->viti <br>";
echo "Memorje: ". $samsung->merr_ramin(). ' Gb. <br>';
echo "Kamera:" .$samsung->merr_kameren() . '<br>';
echo "Versioni: $samsung->marka " .$samsung->merr_ver() . '<br>';



echo "<h2>Te dhenat e Telefonit: </h2> <br>";

echo "Marka: $iphone->marka <br>";
echo "Viti i prodhimit: $iphone->viti <br>";
echo "Memorje: ". $iphone->merr_ramin(). ' Gb. <br>';
echo "Kamera:" .$iphone->merr_kameren() . '<br>';
echo "Versioni: $iphone->marka " .$iphone->merr_ver() . '<br>';






echo "<pre>";
var_dump($samsung);
echo "</pre>";

echo "<pre>";
var_dump($iphone);
echo "</pre>";



 ?>
