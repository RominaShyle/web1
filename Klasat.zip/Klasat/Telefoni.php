<?php

class Telefoni {

public $marka;
public $viti = '';

private $ram;
private $kamera;
private $versioni;


public function vendos_ramin($rami){
$this->ram = $rami;

}

public function merr_ramin(){
  return $this->ram;
}

public function vendos_versionin($ver){
$this->versioni = $ver;

}

public function merr_ver(){
  return $this->versioni;
}

public function vendos_kameren($cam){
$this->kamera = $cam;

}

public function merr_kameren(){
  return $this->kamera;
}

}
echo 123;
