
<?php

//phpinfo();
//funksion qe shmang karakteret si /, hapesire, <> etj

function text_input($data){
 $data = trim($data);
 $data = stripslashes($data);
 $data = htmlspecialchars($data);

}

$cookieName = 'user';
$cookieValue = 'Jane';

setcookie($cookieName,$cookieValue, time() + 86400, '/');
//Delete a cookie - vendosim daten e skadences ne te shkuaren
setcookie($cookieName,$cookieValue, time() - 86400, '/');

setcookie('email','example@gmail.com', time() - 86400, '/');


#inicializojme emer dhe mbiemer, dhe errors perkates dhe i barazojme me string bosh
$name = $l_name = $message = '';
$nameErr = $l_nameErr = '';


// ($_SERVER['REQUEST_METHOD'] == "GET")

//if (isset($_POST) && !empty($_POST)) {
  // code...
//}

if ($_SERVER['REQUEST_METHOD'] == "POST"){
/*
echo "<pre>";
var_dump($_POST);
echo "</pre>";
*/
  if (empty($_POST['emri'])) {
$nameErr = "Te lutem shkruaj emrin!";
  }
  else {
    $name = text_input($_POST['emri']);
  }

  if (empty($_POST['mbiemri'])) {

    $l_nameErr = "Te lutem shkruaj mbiemrin!";

  }else {
    $l_name = text_input($_POST['mbiemri']);
  }




}


 ?>





<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PHP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

<style media="screen">
  .error{
    color:red;
  }


</style>
  </head>
  <body>

    <?php
include_once('includes/header.php');


echo "<pre>";
var_dump($_COOKIE);
echo "</pre>";

     ?>




    <div class="container my-4">


      <div class="row border m-3">
<?php
if (isset($_COOKIE[$cookieName])) {
  echo " <h4> Cookie me emrin $cookieName eshte vendosur dhe e ka vleren $_COOKIE[$cookieName]</h4>";
}
else {
  echo "<h4>Cookie me emrin $cookieName nuk eshte vendosur </h4>";
}


echo "<br> <hr>";

if(count($_COOKIE) > 0){

  echo "Cookies jane te vendosura ne faqe.";
}
else {
  echo "Cookies jane te fshira";
}


echo count($_COOKIE);

?>


      </div>
    <h1 class="text-center"> LEKSIONE PHP</h1>

<?php
#switch case

$dita = "e Merkure";

switch($dita){

case "e Hene":
echo "<br> <p class= 'text-center'>Sot eshte e Hene.</p>";
break;

case "e Merkure":
echo '<br><p class= "text-center"> Sot nuk eshte e Hene.</p>';
break;

default:
echo "<p class= 'text-center'>Nuk e dime ca dite eshte</p>";

}
#KONSTANTET


define("GOOGLE_URL", "https://www.google.com");

echo 'Thank you for visiting -' . GOOGLE_URL . '<br>';

 ?>


 <div class="row">
   <div class="col-md-3 text-center">
     <?php

     # Ciklet ne PHP

     echo "<h5 style='color:red' class='text-center'> Afishoni numrat nga 1 deri ne 10 </h5>";

     $nr = 1;

     while($nr <= 10){

       echo $nr . '<br>';
       $nr++;

     }

      ?>

   </div>


   <div class="col-md-3 text-center">

     <h5> Numrat nga 0-100 me hap 10 </h5>

     <?php

     $nr2 = 0;

     while($nr2 <= 100){

       echo $nr2 . '<br>';
       $nr2 = $nr2 + 10;

     }

      ?>

   </div>

   <div class="col-md-3 text-center">

     <h5> Cikli me for</h5>
     <?php

for($i = 0; $i<=100; $i = $i+10){

  echo "$i <br>";
}

      ?>

   </div>

   <div class="col-md-3 text-center">

     <h5> Cikli me for nga 100-0</h5>
     <?php

for($i = 100; $i>=0; $i = $i-10){

  echo " $i <br>";
}

      ?>

   </div>

 </div>


<div class="row mt-3">

  <div class="col-md-4 border">

    <h5> Ciklet ne Arrays </h5>

    <?php

    # Madhesia e array : sizeof($arr)

$cars = array("Volvo", "BMW", "Fiat");

foreach ($cars as $key => $item){

  echo $item . ' ndodhet ne pozicionin: ' . $key . '<br>';
}



     ?>

  </div>

<div class="col-md-4  border">
  <?php

  $colors=array(
    "White" => "#ffffff",
    "Black" => "#000000",
    "Red" => "#ff0000"
  );

  foreach ($colors as $key => $value) {
    echo "<p style='color:$key'> Kodi i $key eshte $value <br>";
  }

   ?>



</div>


</div>

<div class="row flex-column">
  <div class="">
      <h4> Numrat nga 1-10 bashke me shumen: </h4>
  </div>
  <br>
<div class="">




  <?php

$sum = 0;

for ($i=1; $i <=10 ; $i++) {
  if ($i == 10) {
    echo " $i = ";
  }else {
    echo "$i + ";
  }
  $sum += $i;
}
echo $sum;



$makinat = array(
  array("Volvo", 30, 7),
  array("BMW", 40, 32),
  array("Fiat", 36, 20)
);

    ?>


</div>
</div>

<div class="row">


      <table>

        <tr>
          <th> Makinat </th>
          <th> Sasia </th>
          <th> Shitur </th>
        </tr>

        <?php

        for ($i=0; $i < 3; $i++) {
          echo "<tr>";
          for($j=0; $j <3; $j++){
            echo "<td>";

            echo $makinat[$i][$j];
            echo "</td>";
          }
          echo "</tr>";
        }

         ?>


      </table>

</div>

<hr>
<div class="row border py-2 my-3">


<div class="col-md-3">


<?php


function familyName($name){
  echo "This is $name Smith";
}

familyName('Jane');
echo '<br>';
familyName('John');
echo '<br>';
familyName('Martha');

 ?>
 </div>


 <div class="col-md-3">


 <?php


 function familyName1($name,$year){
   echo "$name Smith was born in $year";
 }



 familyName1('Jane', '1975');
 echo '<br>';
 familyName1('John', '1980');
 echo '<br>';
 familyName1('Martha', '2002');

  ?>
  </div>




  <div class="col-md-3">

    <?php


$a = 30;
$b = 45;


function shtim(){

$GLOBALS['c'] = $GLOBALS['a'] + $GLOBALS['b'];

}

shtim();
echo $c;

/*
echo $_SERVER['PHP_SELF'];
echo $_SERVER['SERVER_SOFTWARE'];
echo "<BR>";
echo $_SERVER['SERVER_ADDR'];

*/
echo "<PRE>";
var_dump($_REQUEST);
echo "</PRE>";
     ?>

  </div>
</div>


<div class="row my-3 p-2 border">

  <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?> " method="post">

    Name *:  <span class="error"> <?php echo $nameErr; ?></span>
    <input type="text" class="form-control" name="emri" placeholder="vendos emrin" required value="<?php if (isset($_POST['emri'])) echo $_POST['emri'];  ?>">

    Last Name *: <span class="error"> <?php echo $l_nameErr; ?></span>
    <input type="text" class="form-control" name="mbiemri" placeholder="vendos mbiemrin" required value = "<?php if (isset($_POST['mbiemri'])) {echo $_POST['mbiemri']; }?>">

<button type="submit"  class="btn btn-success my-2" name="submit" value="dergo">Dergo</button>
  </form>

</div>


<div class="row border m-3">

  <?php

  echo "Koha e plote eshte: " . date('d-m-Y h:i:s') . ' ' ;
  ?>
</div>

      </div>


      <?php
  include_once('includes/footer.php');
       ?>

  </body>
</html>
