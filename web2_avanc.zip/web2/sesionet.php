<?php
session_start(); //gjithmone para tagut html
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sesionet</title>
  </head>
  <body>

<!-- Vendosja e sesionit  -->

<?php

$_SESSION['user'] = 'Jane';
$_SESSION['email'] = 'example@gmail.com';

var_dump($_SESSION);


 ?>
<a href="sesion2.php"> Sesionet 2 </a>
  </body>
</html>
