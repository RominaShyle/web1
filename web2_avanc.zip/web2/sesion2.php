<?php

session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<?php

 echo " Sesioni User e ka vleren " . $_SESSION['user'];
 echo " Sesioni Email e ka vleren " . $_SESSION['email'];


session_unset();
session_destroy();
?>
</body>
</html>
