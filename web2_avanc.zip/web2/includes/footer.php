<footer class="bg-dark p-5 text-center">

  <p style="color:white"> All rights reserved by ATC 2020 </p>
<i class="fa fa-facebook fa-2x mx-2" aria-hidden="true"></i>
<i class="fa fa-instagram fa-2x mx-2" aria-hidden="true"></i>
<i class="fa fa-twitter fa-2x mx-2" aria-hidden="true"></i>
</footer>
