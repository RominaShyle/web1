
    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary sticky-top">
      <!--  Linket e listes se parenditur -->
        <a class="navbar-brand" href="#">
        <img src="images/foto6.png" alt="foto" width="50px">
        </a>

        <!-- buton per Toggle/Collapse  -->

        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#barNavigimi">
        <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="barNavigimi">

              <ul class="navbar-nav flex-fill">

                <li class="nav-item">
                  <a class="nav-link" href="home.html"> Home</a>
                </li>


                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                       Projects
                     </a>

                      <div class="dropdown-menu">
                        <a href="#" class="dropdown-item"> Projekti 1</a>
                        <a href="#" class="dropdown-item"> Projekti 2</a>
                      </div>

                  </li>
                <li class="nav-item">
                  <a class="nav-link" href="about_us.html"> About us </a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="contact.html"> Contact </a>
              </li>
              </ul>



        </div>

    </nav>
